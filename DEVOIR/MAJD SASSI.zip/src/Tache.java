public interface Tache {
    String getNom() ;
    int getCout() ;
}
