//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    CompteEpargne ce1 ;
    ce1 = new CompteEpargne(1,1000,7.40) ;
    System.out.println(ce1);

    /*CompteBancaire cb ;
    CompteEpargne ce ;
    CompteCourant cc ;*/
    /*cb = ce ;
    ce = cb ;
    ce = (CompteEpargne) cb ;
    cc = ce ;
    cc = (CompteCourant) ce ;
     */




}
