//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
import tp1.Compte ;
class Main {
    public static void main(String[] args) {
            Compte c = new Compte(1000, 1289);
            c.consulterSolde();


    }
}

