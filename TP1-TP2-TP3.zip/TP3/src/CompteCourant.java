public class CompteCourant extends CompteBancaire {
    private double salaire ;
    public  CompteCourant() {
        super(20,2434);
    }


}
